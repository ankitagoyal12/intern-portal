<?php
include 'db.php';

// Get form values
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$position = $_POST['position'];

// Insert into database
$sql = "INSERT INTO interns (name, email, phone, position)
        VALUES ('$name', '$email', '$phone', '$position')";

if ($conn->query($sql) === TRUE) {
    echo "Intern registered successfully!<br><br>";
    echo "<a href='index.php'>Go Back</a>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
