<?php
header('Content-Type: application/json');

$data = [
    "name" => "Ankita Goyal",
    "referral_code" => "ankitagoyal2025",
    "donations_raised" => 7500,
    "rewards" => [
        "Free Mentorship Session",
        "Internship Certificate",
        "Premium Slack Badge"
    ]
];

echo json_encode($data, JSON_PRETTY_PRINT);
