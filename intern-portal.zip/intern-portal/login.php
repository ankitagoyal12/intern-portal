<!DOCTYPE html>
<html>
<head>
    <title>Intern Login</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            padding-top: 100px;
        }
        form {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 300px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
        }
        button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background: #007bff;
            color: white;
            border: none;
        }
    </style>
</head>
<body>

<form action="dashboard.php" method="GET">
    <h2>Login</h2>
    <input type="text" name="name" placeholder="Enter your name" required>
    <button type="submit">Continue</button>
</form>

</body>
</html>
