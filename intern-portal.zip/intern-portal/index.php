<!DOCTYPE html>
<html>
<head>
    <title>Intern Dashboard</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f0f4f8;
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }
        form {
            background: #fff;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            width: 100%;
            background: #28a745;
            color: #fff;
            border: none;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>

<form action="submit.php" method="POST">
    <h2>Intern Registration</h2>
    <input type="text" name="name" placeholder="Full Name" required>
    <input type="email" name="email" placeholder="Email Address" required>
    <input type="text" name="phone" placeholder="Phone Number" required>
    <select name="position" required>
        <option value="">Select Position</option>
        <option value="Frontend Developer">Frontend Developer</option>
        <option value="Backend Developer">Backend Developer</option>
        <option value="Full Stack Developer">Full Stack Developer</option>
    </select>
    <button type="submit">Submit</button>
</form>

</body>
</html>
