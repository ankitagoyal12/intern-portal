<!DOCTYPE html>
<html>
<head>
    <title>Leaderboard</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f4f6f8;
            padding: 30px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            width: 80%;
            margin: auto;
            background: #fff;
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #007bff;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .top {
            background-color: #ffd700;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>🏆 Top Intern Leaderboard</h2>

<table>
    <tr>
        <th>Rank</th>
        <th>Name</th>
        <th>Referral Code</th>
        <th>Total Donations</th>
    </tr>
    <tr class="top">
        <td>1</td>
        <td>Ankita Goyal</td>
        <td>ankitagoyal2025</td>
        <td>₹9,800</td>
    </tr>
    <tr>
        <td>2</td>
        <td>Rahul Sharma</td>
        <td>rahul2025</td>
        <td>₹8,500</td>
    </tr>
    <tr>
        <td>3</td>
        <td>Sneha Patel</td>
        <td>sneha2025</td>
        <td>₹7,700</td>
    </tr>
    <tr>
        <td>4</td>
        <td>Vikram Raj</td>
        <td>vikram2025</td>
        <td>₹6,900</td>
    </tr>
    <tr>
        <td>5</td>
        <td>Pooja Singh</td>
        <td>pooja2025</td>
        <td>₹6,200</td>
    </tr>
</table>

</body>
</html>
