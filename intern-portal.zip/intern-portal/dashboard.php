<?php
include 'db.php';

$name = isset($_GET['name']) ? $_GET['name'] : 'Intern';
$referral_code = strtolower(str_replace(' ', '', $name)) . "2025";
$donations = rand(1000, 10000); // Dummy donation amount

$sql = "SELECT * FROM interns";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Intern Dashboard</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f7f9fc;
            padding: 30px;
        }
        .info-box {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 15px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #28a745;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        h2 {
            margin-bottom: 10px;
        }
        ul {
            margin-top: 10px;
            padding-left: 20px;
        }
    </style>
</head>
<body>

<div class="info-box">
    <h2>Welcome, <?= htmlspecialchars($name) ?>!</h2>
    <p><strong>Referral Code:</strong> <?= $referral_code ?></p>
    <p><strong>Total Donations Raised:</strong> ₹<?= $donations ?></p>

    <h3>Rewards / Unlockables</h3>
    <ul>
        <li>🎁 Free Mentorship Session</li>
        <li>🎫 Internship Certificate</li>
        <li>🔥 Premium Slack Badge</li>
    </ul>
</div>

<h2>Registered Interns</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Position</th>
        <th>Registered On</th>
    </tr>

    <?php while($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['name'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['phone'] ?></td>
        <td><?= $row['position'] ?></td>
        <td><?= $row['created_at'] ?></td>
    </tr>
    <?php } ?>

</table>

</body>
</html>
